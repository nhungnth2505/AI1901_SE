import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import random

def crawl_vnexpress_homepage(max_articles=50, out_csv='vnexpress_articles.csv'):
    url = "https://vnexpress.net/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36"
    }

    resp = requests.get(url, headers=headers)
    resp.raise_for_status() 

    soup = BeautifulSoup(resp.text, 'html.parser')

    articles = []
    for a in soup.select('h3.title-news a, h2.title-news a'):
        link = a.get('href')
        title = a.get_text(strip=True)
        if link and title:
            articles.append({
                'title': title,
                'link': link
            })
        if len(articles) >= max_articles:
            break

    df = pd.DataFrame(articles)
    return df

if __name__ == "__main__":
    df = crawl_vnexpress_homepage(max_articles=50)
    print(df.head())

