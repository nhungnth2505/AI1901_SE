import requests
from bs4 import BeautifulSoup

url = "https://vnexpress.net/"

response = requests.get(url)
response.encoding = "utf-8"  

if response.status_code == 200:
    soup = BeautifulSoup(response.text, "html.parser")

    titles = []
    for item in soup.find_all("h3", class_="title-news"):
        title = item.get_text(strip=True)
        titles.append(title)

    print("Các tiêu đề bài báo trên VNExpress:")
    for i, t in enumerate(titles[:10], 1): 
        print(f"{i}. {t}")
else:
    print("Không thể truy cập trang web")
