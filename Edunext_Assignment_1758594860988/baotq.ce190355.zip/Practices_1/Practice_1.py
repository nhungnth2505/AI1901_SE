import requests
from bs4 import BeautifulSoup
import re
import json

def scrape_trip_hotels():
    # URL của trang Trip.com
    url = "https://vn.trip.com/hotels/list"
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "vi-VN,vi;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Cache-Control": "max-age=0"
    }
    
    # Parameters từ URL của bạn
    params = {
        "cityId": "36145",
        "provinceId": "0",
        "districtId": "0",
        "countryId": "111",
        "cityName": "Cần Thơ",
        "destName": "Cần Thơ, Việt Nam",
        "searchWord": "Cần Thơ",
        "searchType": "CT",
        "optionId": "36145",
        "searchValue": "19|36145*19*36145",
        "checkin": "2025-09-23",
        "checkout": "2025-09-24",
        "crn": "1",
        "adult": "2",
        "listFilters": "29~1*29*1~2*2",
        "curr": "USD",
        "locale": "vi-VN",
        "old": "1"
    }
    
    session = requests.Session()
    session.headers.update(headers)
    
    try:
        print("Đang truy cập trang Trip.com...")
        response = session.get(url, params=params, timeout=30)
        response.raise_for_status()
        
        # Parse HTML
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Tìm tất cả các hotel cards
        hotel_cards = soup.find_all('div', class_=re.compile(r'hotel-item|hotel-card'))
        
        hotels = []
        
        for card in hotel_cards:
            try:
                hotel_data = {}
                
                # Tên khách sạn
                name_elem = card.find('div', class_=re.compile(r'hotel-name|name'))
                if name_elem:
                    hotel_data['hotelName'] = name_elem.get_text(strip=True)
                else:
                    # Fallback - tìm trong text có chứa giá
                    name_text = card.get_text()
                    # Tìm tên hotel (thường ở đầu, trước giá)
                    name_match = re.search(r'^([A-Za-z0-9\s&.,\-]+?)(?=\d+\s*US\$|$)', name_text)
                    if name_match:
                        hotel_data['hotelName'] = name_match.group(1).strip()
                
                # Giá
                price_elem = card.find('span', class_=re.compile(r'price|amount|final-price'))
                if not price_elem:
                    price_elem = card.find(text=re.compile(r'\d+\s*US\$'))
                
                if price_elem:
                    price_text = price_elem.get_text() if isinstance(price_elem, str) else price_elem.get_text()
                    price_match = re.search(r'(\d+(?:\.\d+)?)\s*US\$', price_text)
                    if price_match:
                        hotel_data['price'] = float(price_match.group(1))
                
                # Địa chỉ/Vị trí
                location_elem = card.find('div', class_=re.compile(r'location|address|distance'))
                if location_elem:
                    location_text = location_elem.get_text(strip=True)
                    # Extract khoảng cách từ trung tâm
                    distance_match = re.search(r'(\d+(?:,\d+)?)\s*(?:km|km từ trung tâm)', location_text)
                    if distance_match:
                        hotel_data['distance'] = distance_match.group(1)
                    hotel_data['location'] = location_text
                
                # Điểm đánh giá
                rating_elem = card.find('span', class_=re.compile(r'rating|score'))
                if rating_elem:
                    rating_text = rating_elem.get_text(strip=True)
                    rating_match = re.search(r'(\d+(?:,\d+)?)/10', rating_text)
                    if rating_match:
                        hotel_data['rating'] = float(rating_match.group(1).replace(',', '.'))
                
                # Số đánh giá
                review_elem = card.find('span', class_=re.compile(r'review|reviews'))
                if review_elem:
                    review_text = review_elem.get_text(strip=True)
                    review_match = re.search(r'(\d+(?:,\d+)?)\s*đánh giá', review_text)
                    if review_match:
                        hotel_data['reviews'] = review_match.group(1)
                
                # Link chi tiết (nếu có)
                link_elem = card.find('a', href=True)
                if link_elem:
                    hotel_data['hotelUrl'] = "https://vn.trip.com" + link_elem['href']
                
                if hotel_data.get('hotelName'):  # Chỉ thêm nếu có tên
                    hotels.append(hotel_data)
                    
            except Exception as e:
                print(f"Lỗi khi parse hotel card: {e}")
                continue
        
        # Nếu không tìm thấy hotel cards, thử tìm script tags chứa JSON data
        if not hotels:
            print("Không tìm thấy hotel cards, đang tìm trong script tags...")
            scripts = soup.find_all('script')
            for script in scripts:
                if script.string and 'hotelList' in script.string:
                    try:
                        # Extract JSON data
                        json_match = re.search(r'\{.*"hotelList".*\}', script.string, re.DOTALL)
                        if json_match:
                            json_data = json.loads(json_match.group())
                            hotels = json_data.get('hotelList', [])
                            break
                    except json.JSONDecodeError:
                        continue
        
        return hotels
        
    except requests.RequestException as e:
        print(f"Lỗi request: {e}")
        return []
    except Exception as e:
        print(f"Lỗi không xác định: {e}")
        return []

def main():
    print("=== SCRAPER KHÁCH SẠN TRIP.COM CẦN THƠ ===")
    print("Ngày check-in: 23/09/2025")
    print("Ngày check-out: 24/09/2025")
    print("Số người lớn: 2")
    print("-" * 60)
    
    hotels = scrape_trip_hotels()
    
    if not hotels:
        print("❌ Không tìm thấy khách sạn nào!")
        print("💡 Gợi ý:")
        print("- Kiểm tra kết nối internet")
        print("- Thử lại sau vài phút")
        print("- Có thể Trip.com đã thay đổi cấu trúc trang")
        return
    
    print(f"✅ Tìm thấy {len(hotels)} khách sạn\n")
    
    # Sắp xếp theo giá tăng dần
    hotels_sorted = sorted(hotels, key=lambda x: x.get('price', 999))
    
    # Hiển thị top 10 khách sạn rẻ nhất
    for i, hotel in enumerate(hotels_sorted[:10], 1):
        print(f"{i}. {hotel.get('hotelName', 'N/A')}")
        print(f"   💰 Giá: ${hotel.get('price', 'N/A')}")
        
        if 'rating' in hotel:
            print(f"   ⭐ Đánh giá: {hotel['rating']}/10")
        if 'reviews' in hotel:
            print(f"   📝 Số đánh giá: {hotel['reviews']}")
        if 'distance' in hotel:
            print(f"   📍 Khoảng cách: {hotel['distance']}km từ trung tâm")
        if 'location' in hotel:
            print(f"   🏠 Vị trí: {hotel['location'][:50]}...")
        
        if 'hotelUrl' in hotel:
            print(f"   🔗 Link: {hotel['hotelUrl']}")
        
        print("-" * 60)
    
    # Thống kê
    prices = [h.get('price', 0) for h in hotels]
    if prices:
        avg_price = sum(prices) / len(prices)
        min_price = min(prices)
        max_price = max(prices)
        print(f"\n📊 THỐNG KÊ:")
        print(f"   Giá trung bình: ${avg_price:.1f}")
        print(f"   Giá thấp nhất: ${min_price}")
        print(f"   Giá cao nhất: ${max_price}")
    
    # Lưu vào file JSON
    with open('cantho_hotels.json', 'w', encoding='utf-8') as f:
        json.dump(hotels, f, ensure_ascii=False, indent=2)
    print(f"\n💾 Đã lưu {len(hotels)} khách sạn vào file cantho_hotels.json")

if __name__ == "__main__":
    main()